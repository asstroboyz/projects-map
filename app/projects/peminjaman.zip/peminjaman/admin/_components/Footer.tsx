"use client";

export default function Footer() {
  return (
    <footer className="h-10 text-xs text-gray-500 flex items-center justify-center border-t">
      © 2026 LAB ESAE
    </footer>
  );
}
