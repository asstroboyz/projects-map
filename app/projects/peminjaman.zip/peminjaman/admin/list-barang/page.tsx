export default function ListBarangPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">
        List Barang
      </h1>

      {/* nanti isi table */}
    </div>
  );
}
