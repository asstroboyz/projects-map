"use client";

import { useDashboardData } from "../_components/useDashboardData";
import PeminjamanStats from "../_components/PeminjamanStats";

export default function AdminDashboard() {
  const data = useDashboardData();
  if (!data) return null;

  return (
    <div className="space-y-8">
      {/* HEADER */}
      <div>
        <p className="text-sm text-slate-500">Selamat Datang Kembali</p>
        <h1 className="text-2xl font-semibold text-slate-800">Administrator</h1>
      </div>

      {/* STATS */}
      <PeminjamanStats data={data} />

      {/* CHART */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* BAR */}
        <div className="bg-white rounded-xl p-6 border">
          <h3 className="font-semibold mb-4">Top Barang Dipinjam</h3>
          <div className="h-48 flex items-end gap-4">
            {data.topBarang.map(b => (
              <div key={b.name} className="flex-1 text-center">
                <div
                  className="bg-indigo-400 rounded-t-md mx-auto"
                  style={{ height: `${Math.max(b.value * 24, 20)}px` }}
                />
                <p className="text-xs mt-2">{b.name}</p>
              </div>
            ))}
          </div>
        </div>

        {/* PIE */}
        <div className="bg-white rounded-xl p-6 border flex flex-col items-center">
          <h3 className="font-semibold mb-4 self-start">Persentase</h3>
          <div className="w-40 h-40 rounded-full bg-indigo-500 flex items-center justify-center text-white">
            <div className="text-center">
              <div className="font-semibold">{data.topBarang[0]?.name}</div>
              <div className="text-sm opacity-80">
                {data.topBarang[0]?.value} items
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
