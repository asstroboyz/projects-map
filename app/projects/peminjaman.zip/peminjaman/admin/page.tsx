import { redirect } from "next/navigation";

export default function AdminPage() {
  redirect("/projects/peminjaman/admin/dashboard");
}
